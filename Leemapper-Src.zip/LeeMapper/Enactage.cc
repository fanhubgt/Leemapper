#include "Enactage.h"

Enactage::Enactage(){
    
}

Enactage::Enactage(action a, location l, temporal t):
act(a),
loc(l),
temp(t){
    
}
action Enactage::getAction(){
    return act;
}

temporal Enactage::getTemporal(){
    return temp;
}

location Enactage::getLocation(){
    return loc;
}

void Enactage::setAction(action a){
    act=a;
}

void Enactage::setLocation(location l){
    loc=l;
}

void Enactage::setTemporal(temporal t){
    temp=t;
}

