#include "interestact.h"

interestact::interestact(){
//    A=new Enact();
 //   I=new Enactage();
}

interestact::interestact(Enactage ia, Enact en):
A(en),
I(ia){
    
}

