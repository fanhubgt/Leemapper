//
// File:   LEEType.h
// Author: appiah
//
// Created on 4 January 1980, 00:3


#ifndef _LEETYPE_H
#define	_LEETYPE_H

typedef char* action;
typedef char* location;
typedef char* temporal;
typedef char* rank;
typedef char* interest;

#endif	/* _LEETYPE_H */

