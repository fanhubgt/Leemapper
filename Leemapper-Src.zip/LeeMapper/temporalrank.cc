#include "temporalrank.h"

temporalrank::temporalrank(){
    
}

temporalrank::temporalrank(Enact ee, Enactage age){
    R=age;
    T=ee;
}

Enact temporalrank::getEnactment(){
    return T;
}

Enactage temporalrank::getEngagement(){
    return R;
}

char* temporalrank::toString(){
    return "rank_i---> t";
}
